#ifndef FT_H
# define FT_H

typedef struct s_firstLine
{
    int     nbLine;
    int     nbCol;
    char    charVoid;
    char    charFull;
    char    charQue;
}   t_fristLine;

#endif
